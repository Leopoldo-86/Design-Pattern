import java.util.ArrayList;

/**
 * @author Leopoldo Medeiros_2017288
 * Code based on Amilcar's classes
 */

public class Main {

    public static void main(String[] args){

        Menu menu = new Menu();

       
    }
}
